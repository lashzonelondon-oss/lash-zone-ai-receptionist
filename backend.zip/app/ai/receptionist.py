"""
AI Receptionist - Core conversation engine for Lash Zone London
Uses OpenAI GPT-4o for natural conversation and TTS for voice
"""

import os
import json
import asyncio
from typing import Optional, Dict, List, Any
from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum

from openai import OpenAI


class CallOutcome(Enum):
    BOOKING_COMPLETED = "booking_completed"
    INFO_PROVIDED = "info_provided"
    BOOKING_LINK_SENT = "booking_link_sent"
    ESCALATED = "escalated"
    VOICEMAIL_LEFT = "voicemail_left"
    HUNG_UP = "hung_up"


class EscalationType(Enum):
    COMPLAINT = "complaint"
    REFUND_REQUEST = "refund_request"
    ALLERGIC_REACTION = "allergic_reaction"
    MANAGEMENT_NEEDED = "management_needed"
    COMPLEX_ISSUE = "complex_issue"


@dataclass
class ClientInfo:
    name: Optional[str] = None
    phone: Optional[str] = None
    email: Optional[str] = None
    preferred_service: Optional[str] = None
    is_returning: bool = False


@dataclass
class BookingRequest:
    service: Optional[str] = None
    preferred_date: Optional[str] = None
    preferred_time: Optional[str] = None
    notes: Optional[str] = None


@dataclass
class EscalationRequest:
    escalation_type: EscalationType
    client_name: Optional[str] = None
    client_phone: Optional[str] = None
    issue_summary: str = ""
    details: Dict[str, Any] = field(default_factory=dict)


@dataclass
class CallContext:
    caller_number: str
    conversation_history: List[Dict[str, str]] = field(default_factory=list)
    client_info: ClientInfo = field(default_factory=ClientInfo)
    booking_request: BookingRequest = field(default_factory=BookingRequest)
    escalation: Optional[EscalationRequest] = None
    current_intent: Optional[str] = None
    outcome: Optional[CallOutcome] = None
    needs_booking_link: bool = False
    booking_link_sent: bool = False
    services_discussed: List[str] = field(default_factory=list)

    def add_message(self, role: str, content: str):
        self.conversation_history.append({"role": role, "content": content})

    def to_json(self) -> str:
        return json.dumps({
            "caller_number": self.caller_number,
            "conversation_history": self.conversation_history,
            "client_info": {
                "name": self.client_info.name,
                "phone": self.client_info.phone,
                "email": self.client_info.email,
                "preferred_service": self.client_info.preferred_service,
                "is_returning": self.client_info.is_returning
            },
            "booking_request": {
                "service": self.booking_request.service,
                "preferred_date": self.booking_request.preferred_date,
                "preferred_time": self.booking_request.preferred_time,
                "notes": self.booking_request.notes
            },
            "outcome": self.outcome.value if self.outcome else None,
            "services_discussed": self.services_discussed
        })


class LashZoneReceptionist:
    """
    AI Receptionist for Lash Zone London
    Warm, professional, and focused on excellent customer service
    """

    # System prompt defining the AI's personality and capabilities
    SYSTEM_PROMPT = """You are Luna, the friendly and professional AI receptionist for Lash Zone London, a premier beauty and lash studio in London.

## Your Personality
- Warm, welcoming, and genuinely caring
- Professional but personable - like an experienced salon receptionist
- Enthusiastic about helping clients feel beautiful
- Proactive in offering helpful suggestions
- Empathetic and understanding

## Studio Information
- **Name:** Lash Zone London
- **Location:** London, UK
- **Phone:** 07748252038
- **Hours:** Monday-Saturday 9am-7pm, Sunday 10am-5pm
- **Services:** Eyelash extensions (classic, hybrid, volume, mega volume), brow lamination, lash lifts, facial treatments

## Service Menu & Pricing
1. **Classic Lash Extensions** - £45-65 (90-120 min)
2. **Hybrid Lash Extensions** - £55-75 (90-120 min)
3. **Volume Lash Extensions** - £65-85 (120-150 min)
4. **Mega Volume Lash Extensions** - £85-110 (150-180 min)
5. **Lash Lift** - £35-50 (45-60 min)
6. **Brow Lamination** - £35-45 (45-60 min)
7. **Classic Facial** - £55-75 (60 min)
8. **Deluxe Facial** - £85-110 (90 min)

## Policies
- **Booking:** Online booking recommended, call to book
- **Cancellation:** 24 hours notice required
- **Payment:** Cash, card accepted
- **Aftercare:** Provided after each treatment

## Your Capabilities
1. Answer questions about services, pricing, and availability
2. Help clients book appointments
3. Provide directions and parking info
4. Send booking links via SMS
5. Collect client information
6. Identify when to escalate to management

## Escalation Triggers
Escalate to management when caller mentions:
- Complaint or dissatisfaction
- Refund request
- Allergic reaction
- Need for management decision
- Complex or unusual requests

## Conversation Guidelines
- Keep responses concise for voice conversation (2-3 sentences max)
- Use the caller's name when they provide it
- Confirm understanding before taking action
- End each response with a helpful follow-up question or option
- Always offer to help with anything else

## Response Style
- Use phrases like: "Absolutely!", "Happy to help!", "Great choice!"
- Be enthusiastic but natural
- Show genuine interest in helping
- Never say "I don't know" - always offer to find out or escalate

Start every conversation with a warm greeting introducing yourself and offering help.
"""

    def __init__(self):
        self.client = OpenAI(api_key=os.environ.get("OPENAI_API_KEY"))
        self.model = "gpt-4o"
        self.voice = "alloy"  # Natural, warm voice

        # Escalation keywords
        self.escalation_keywords = [
            "complaint", "unhappy", "dissatisfied", "angry", "frustrated",
            "refund", "money back", "not happy", "terrible", "worst",
            "allergic", "reaction", "swelling", "irritation", "rash",
            "manager", "supervisor", "owner", "speak to someone in charge",
            "serious", "emergency", "medical"
        ]

    async def generate_response(self, call_context: CallContext, user_message: str) -> str:
        """
        Generate AI response using GPT-4o
        """
        # Add user message to history
        call_context.add_message("user", user_message)

        # Check for escalation keywords
        if self._should_escalate(user_message):
            call_context.escalation = EscalationRequest(
                escalation_type=EscalationType.COMPLEX_ISSUE,
                issue_summary=f"Caller expressed concern: {user_message}"
            )

        # Build messages for API
        messages = [{"role": "system", "content": self.SYSTEM_PROMPT}]
        messages.extend(call_context.conversation_history)

        # Add context about booking link status
        if call_context.needs_booking_link and not call_context.booking_link_sent:
            messages.append({
                "role": "system",
                "content": "IMPORTANT: The caller needs a booking link. When appropriate, offer to send one via SMS."
            })

        # Generate response
        response = self.client.chat.completions.create(
            model=self.model,
            messages=messages,
            max_tokens=500,
            temperature=0.8
        )

        ai_response = response.choices[0].message.content

        # Add to conversation history
        call_context.add_message("assistant", ai_response)

        return ai_response

    def _should_escalate(self, message: str) -> bool:
        """Check if message contains escalation keywords"""
        message_lower = message.lower()
        return any(keyword in message_lower for keyword in self.escalation_keywords)

    async def generate_speech(self, text: str, voice: str = "alloy") -> bytes:
        """
        Generate speech from text using OpenAI TTS
        Returns audio bytes
        """
        response = self.client.audio.speech.create(
            model="tts-1",
            voice=voice,
            input=text,
            response_format="ulaw"  # 8-bit ulaw for Twilio compatibility
        )

        return response.content

    async def transcribe_audio(self, audio_bytes: bytes) -> str:
        """
        Transcribe audio using Whisper API
        """
        import io

        # Create file-like object
        audio_file = io.BytesIO(audio_bytes)
        audio_file.name = "audio.wav"

        transcript = self.client.audio.transcriptions.create(
            model="whisper-1",
            file=audio_file
        )

        return transcript.text

    def extract_booking_info(self, message: str) -> Optional[Dict[str, str]]:
        """Extract potential booking information from message"""
        info = {}

        # Service keywords
        services = ["classic", "hybrid", "volume", "mega volume", "lash lift", "brow lamination", "facial"]
        for service in services:
            if service in message.lower():
                info["service"] = service
                break

        # Time references
        if "tomorrow" in message.lower():
            info["timeframe"] = "tomorrow"
        elif "today" in message.lower():
            info["timeframe"] = "today"
        elif "this week" in message.lower():
            info["timeframe"] = "this week"

        return info if info else None

    def format_booking_confirmation(self, call_context: CallContext) -> str:
        """Format booking confirmation message"""
        client = call_context.client_info
        booking = call_context.booking_request

        parts = []

        if client.name:
            parts.append(f"Great, {client.name}!")

        if booking.service:
            parts.append(f"I've noted you're interested in {booking.service}.")

        if booking.preferred_date or booking.preferred_time:
            parts.append(f"We'll confirm your preferred time shortly.")

        parts.append("You'll receive a text message shortly with your booking details.")
        parts.append("Is there anything else I can help you with?")

        return " ".join(parts)

    def format_escalation_message(self, call_context: CallContext) -> str:
        """Format message for escalation scenarios"""
        return (
            "I completely understand, and I'm so sorry you're experiencing this. "
            "Let me make sure our management team is aware so they can call you back personally "
            "and resolve this as quickly as possible. "
            "Could I take your name and the best number to reach you?"
        )


# Singleton instance
receptionist = LashZoneReceptionist()
