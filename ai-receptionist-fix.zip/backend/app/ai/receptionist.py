"""
AI Receptionist - Enhanced conversation engine with dynamic config loading
Loads comprehensive system prompt from database/config
"""

import os
import json
import asyncio
from typing import Optional, Dict, List, Any
from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum

from openai import OpenAI


class CallOutcome(Enum):
    BOOKING_COMPLETED = "booking_completed"
    INFO_PROVIDED = "info_provided"
    BOOKING_LINK_SENT = "booking_link_sent"
    ESCALATED = "escalated"
    VOICEMAIL_LEFT = "voicemail_left"
    HUNG_UP = "hung_up"


class EscalationType(Enum):
    COMPLAINT = "complaint"
    REFUND_REQUEST = "refund_request"
    ALLERGIC_REACTION = "allergic_reaction"
    MANAGEMENT_NEEDED = "management_needed"
    COMPLEX_ISSUE = "complex_issue"


@dataclass
class ClientInfo:
    name: Optional[str] = None
    phone: Optional[str] = None
    email: Optional[str] = None
    preferred_service: Optional[str] = None
    is_returning: bool = False


@dataclass
class BookingRequest:
    service: Optional[str] = None
    preferred_date: Optional[str] = None
    preferred_time: Optional[str] = None
    notes: Optional[str] = None


@dataclass
class EscalationRequest:
    escalation_type: EscalationType
    client_name: Optional[str] = None
    client_phone: Optional[str] = None
    issue_summary: str = ""
    details: Dict[str, Any] = field(default_factory=dict)


@dataclass
class CallContext:
    caller_number: str
    conversation_history: List[Dict[str, str]] = field(default_factory=list)
    client_info: ClientInfo = field(default_factory=ClientInfo)
    booking_request: BookingRequest = field(default_factory=BookingRequest)
    escalation: Optional[EscalationRequest] = None
    current_intent: Optional[str] = None
    outcome: Optional[CallOutcome] = None
    needs_booking_link: bool = False
    booking_link_sent: bool = False
    services_discussed: List[str] = field(default_factory=list)

    def add_message(self, role: str, content: str):
        self.conversation_history.append({"role": "user" if role == "user" else "assistant", "content": content})

    def to_json(self) -> str:
        return json.dumps({
            "caller_number": self.caller_number,
            "conversation_history": self.conversation_history,
            "client_info": {
                "name": self.client_info.name,
                "phone": self.client_info.phone,
                "email": self.client_info.email,
                "preferred_service": self.client_info.preferred_service,
                "is_returning": self.client_info.is_returning
            },
            "booking_request": {
                "service": self.booking_request.service,
                "preferred_date": self.booking_request.preferred_date,
                "preferred_time": self.booking_request.preferred_time,
                "notes": self.booking_request.notes
            },
            "outcome": self.outcome.value if self.outcome else None,
            "services_discussed": self.services_discussed
        })


# Fallback system prompt if config fetch fails
FALLBACK_SYSTEM_PROMPT = """You are the receptionist at Lash Zone London, an award-winning luxury lash and brow studio in London.

YOUR ROLE: You are a warm, knowledgeable, and confident luxury beauty salon receptionist. You sound human, natural, and genuinely helpful — never robotic or scripted. You represent Lash Zone London with professionalism and pride.

SERVICES:
- Eyelash Extensions: Classic, Hybrid, Volume, Mega Volume, Wet Look, Kim K Style, Anime, Wispy, Cat Eye Styling, Lash Infills, Lash Removal
- Natural Lash Treatments: Korean Lash Lift, Lash Lift & Tint, Lash Tint
- Brow Services: Brow Lamination, Brow Tint, Brow Styling
- Training: Beginner Lash Courses, Advanced Lash Courses, Mentoring, Professional Lash Education

LOCATION: 787 Commercial Road, Unit 2A, London E14 7HG
PHONE: 07748252038

RESPONSE STYLE:
- Warm, detailed, 2-5 sentences
- Ask follow-up questions to help clients
- Be friendly, confident, educational
- Use British English
- Never say "I am an AI"

BOOKING: Offer to send booking link via SMS
PRICING: Never invent prices - offer to send booking link
URGENT: Allergic reactions → collect name, phone, date → escalate immediately

Start with warm greeting, introduce yourself, offer help.
"""


class LashZoneReceptionist:
    """
    AI Receptionist for Lash Zone London
    Loads comprehensive system prompt from config
    """

    def __init__(self):
        self.client = OpenAI(api_key=os.environ.get("OPENAI_API_KEY"))
        self.model = os.environ.get("AI_MODEL", "gpt-4o")
        self.voice = os.environ.get("AI_VOICE", "alloy")
        self._system_prompt = None
        self._config_loaded = False

        # Escalation keywords
        self.escalation_keywords = [
            "complaint", "unhappy", "dissatisfied", "angry", "frustrated",
            "refund", "money back", "not happy", "terrible", "worst",
            "allergic", "reaction", "swelling", "irritation", "rash",
            "manager", "supervisor", "owner", "speak to someone in charge",
            "serious", "emergency", "medical"
        ]

    async def load_config(self):
        """Load system prompt from config endpoint or environment"""
        if self._config_loaded:
            return

        try:
            # Try to fetch from config endpoint
            import httpx
            base_url = os.environ.get("BASE_URL", "https://talented-fulfillment-production-8f33.up.railway.app")
            async with httpx.AsyncClient() as client:
                response = await client.get(f"{base_url}/admin/config", timeout=5.0)
                if response.status_code == 200:
                    data = response.json()
                    if "config" in data and "ai_settings" in data["config"]:
                        self._system_prompt = data["config"]["ai_settings"].get("system_prompt", FALLBACK_SYSTEM_PROMPT)
                        self._config_loaded = True
                        print("✅ Loaded AI config from database")
                        return
        except Exception as e:
            print(f"Could not load config from endpoint: {e}")

        # Try environment variable
        env_prompt = os.environ.get("AI_SYSTEM_PROMPT")
        if env_prompt:
            self._system_prompt = env_prompt
            self._config_loaded = True
            print("✅ Loaded AI config from environment")
            return

        # Fallback
        self._system_prompt = FALLBACK_SYSTEM_PROMPT
        self._config_loaded = True
        print("⚠️ Using fallback AI config")

    @property
    def system_prompt(self) -> str:
        """Get the current system prompt, loading from config if needed"""
        if not self._config_loaded:
            # Run synchronously on first access (will be called from startup)
            pass
        return self._system_prompt or FALLBACK_SYSTEM_PROMPT

    async def generate_response(self, call_context: CallContext, user_message: str) -> str:
        """
        Generate AI response using GPT-4o
        """
        # Ensure config is loaded
        if not self._config_loaded:
            await self.load_config()

        # Add user message to history
        call_context.add_message("user", user_message)

        # Check for escalation keywords
        if self._should_escalate(user_message):
            call_context.escalation = EscalationRequest(
                escalation_type=EscalationType.COMPLEX_ISSUE,
                issue_summary=f"Caller expressed concern: {user_message}"
            )

        # Build messages for API
        messages = [{"role": "system", "content": self.system_prompt}]

        # Add conversation history
        for msg in call_context.conversation_history:
            messages.append({"role": msg["role"], "content": msg["content"]})

        # Add context about booking link status
        if call_context.needs_booking_link and not call_context.booking_link_sent:
            messages.append({
                "role": "system",
                "content": "IMPORTANT: The caller needs a booking link. When appropriate, offer to send one via SMS."
            })

        # Generate response with higher token limit for detailed answers
        response = self.client.chat.completions.create(
            model=self.model,
            messages=messages,
            max_tokens=800,  # Increased for detailed responses
            temperature=0.7
        )

        ai_response = response.choices[0].message.content

        # Add to conversation history
        call_context.add_message("assistant", ai_response)

        return ai_response

    def _should_escalate(self, message: str) -> bool:
        """Check if message contains escalation keywords"""
        message_lower = message.lower()
        return any(keyword in message_lower for keyword in self.escalation_keywords)

    async def generate_speech(self, text: str, voice: str = "alloy") -> bytes:
        """
        Generate speech from text using OpenAI TTS
        Returns audio bytes
        """
        response = self.client.audio.speech.create(
            model="tts-1",
            voice=voice,
            input=text,
            response_format="ulaw"  # 8-bit ulaw for Twilio compatibility
        )

        return response.content

    async def transcribe_audio(self, audio_bytes: bytes) -> str:
        """
        Transcribe audio using OpenAI Whisper
        """
        import io

        # Create file-like object with wav extension for Whisper
        audio_file = io.BytesIO(audio_bytes)
        audio_file.name = "audio.wav"

        try:
            transcript = self.client.audio.transcriptions.create(
                model="whisper-1",
                file=audio_file,
                language="en"
            )
            return transcript.text if transcript.text else ""
        except Exception as e:
            print(f"Transcription error: {e}")
            return ""


# Singleton instance
receptionist = LashZoneReceptionist()